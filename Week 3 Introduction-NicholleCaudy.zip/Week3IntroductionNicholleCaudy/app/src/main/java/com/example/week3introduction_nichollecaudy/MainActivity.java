package com.example.week3introduction_nichollecaudy;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TextWatcher {
    EditText nameText;
    TextView textGreeting;
    Button SayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get nameText instance
        nameText = findViewById(R.id.nameText);

        //get textGreeting instance
        textGreeting = findViewById(R.id.textGreeting);

        //get SayHello instance
        SayHello = findViewById(R.id.buttonSayHello);

        //disable say hello button initially
        SayHello.setEnabled(false);




        //attach text changer listener for nameText
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()){
                    //if empty disable sayHello button
                    SayHello.setEnabled(false);
                }
                else{
                    //else enable sayHelloButton
                    SayHello.setEnabled(true);
                }

            }
        });
    }
    //on click listener for SayHello button
    public void SayHello (View view){
        String name = nameText.getText().toString();
        //else greet user after name is entered
        if(name.isEmpty()){
            //if nameText is empty message
            textGreeting.setText(R.string.please_enter_name);
        }
        else {
            textGreeting.setText("Hello " + nameText);
        }
    }



    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}




