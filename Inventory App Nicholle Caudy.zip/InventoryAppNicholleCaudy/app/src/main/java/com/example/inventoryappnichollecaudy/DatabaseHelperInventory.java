package com.example.inventoryappnichollecaudy;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TableLayout;

public class DatabaseHelperInventory extends SQLiteOpenHelper {
    //constant variables for database
    private static final String DATABASE_NAME = "InventoryItems.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "Inventory Items";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "Item Description";
    public static final String COLUMN_ITEM_NUMBER = "Item Number";
    public static final String COLUMN_QUANTITY = "Quantity";

    //constructor for database handler
    public DatabaseHelperInventory(Context context){
        super(context, DATABASE_NAME, null, 1);
    }

    //create database by running a SQLite query
    @Override
    public void onCreate(SQLiteDatabase db) {
         String CREATE_TABLE;
        CREATE_TABLE = "CREATE TABLE " + TABLE_NAME +  " ("
                + COLUMN_ID + "INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NAME + "TEXT NOT NULL, "
                + COLUMN_ITEM_NUMBER + "INTEGER NOT NULL, "
                + COLUMN_QUANTITY + "INTEGER NOT NULL);";
        db.execSQL(CREATE_TABLE);
    }

        //method to upgrade
        @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    //method to add new items to SQLite database
    public void insertItems(String itemDescription, int Quantity, int itemNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, itemDescription);
        values.put(COLUMN_ITEM_NUMBER, itemNumber);
        values.put(COLUMN_QUANTITY, Quantity);

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    //method to display items
    public Cursor getAllItems(){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, null, null, null,null,null, null);
    }

    //method to update items in database
    public void updateItem(int id, String itemDescription, int itemNumber, int Quantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, itemDescription);
        values.put(COLUMN_ITEM_NUMBER, itemNumber);
        values.put(COLUMN_QUANTITY, Quantity);

        db.update(TABLE_NAME, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    //method to delete items from database
    public void deleteItem(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();

    }
}


