package com.example.inventoryappnichollecaudy;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivityInventory extends AppCompatActivity {
    //creating variables for button, EditText, and databaseHelper
    private EditText enterItemDescriptionEditText, itemNumberEditText, quantityEditText;
    private Button addItemSaveButton;
    private DatabaseHelperInventory databaseHelperInventory;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item_activity);

        //initializing all variables
        enterItemDescriptionEditText = findViewById(R.id.enterItemDescriptionEditText);
        itemNumberEditText = findViewById(R.id.itemNumberEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        ImageButton addItemSaveButton = findViewById(R.id.addItemSaveButton);

        //creating databaseHelper call and passing context to it.
        databaseHelperInventory = new DatabaseHelperInventory(MainActivityInventory.this);

        //on click listener for addItemSaveButton
        addItemSaveButton.setOnClickListener(v -> {
            //get data from all EditText fields
            String itemDescription = enterItemDescriptionEditText.getText().toString();
            Integer itemNumber = Integer.valueOf(itemNumberEditText.getText().toString());
            Integer quantity = Integer.valueOf(quantityEditText.getText().toString());

            //validating if EditTexts are empty or not
            if (itemNumber.equals("") || itemDescription.isEmpty() || quantity.equals("")) {
                //inserts new items to database
                databaseHelperInventory.insertItems(itemDescription, itemNumber, quantity);

                //after item added display a Toast message.
                Toast.makeText(MainActivityInventory.this, "Item(s) has been added.", Toast.LENGTH_SHORT).show();
                enterItemDescriptionEditText.setText("");
                itemNumberEditText.setText("");
                quantityEditText.setText("");
            }
            else {
                //if any field left empty display a Toast message.
                Toast.makeText(MainActivityInventory.this, "Please complete all fields", Toast.LENGTH_SHORT).show();

            }


        });

    }
}
