package com.example.inventoryappnichollecaudy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    //constant variables for database
    Button loginButton, newUserButton;
    EditText usernameText, passwordText;

    DatabaseHelperLogin databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        databaseHelper = new DatabaseHelperLogin(this);

        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);

        loginButton = findViewById(R.id.loginButton);
        newUserButton = findViewById(R.id.newUserButton);

        //on click listener for newUserButton
        newUserButton.setOnClickListener(v -> {
            Intent intent = new Intent(Login.this, MainActivityLogin.class);
            startActivity(intent);
        });
        //on click listener for loginButton
        loginButton.setOnClickListener(v -> {
            String username = usernameText.getText().toString();
            String password = passwordText.getText().toString();
            //check authentication
            Boolean checkLogin = databaseHelper.CheckLogin(username, password);
            //Messages stating login successful or not
            if (checkLogin) {
                Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "Invalid Username or Password", Toast.LENGTH_SHORT).show();
            }
        });

        }
    }

