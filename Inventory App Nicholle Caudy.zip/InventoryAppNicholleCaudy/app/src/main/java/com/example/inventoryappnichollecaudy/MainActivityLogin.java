package com.example.inventoryappnichollecaudy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivityLogin extends AppCompatActivity {
    DatabaseHelperLogin databaseHelper;

    //constant variables for button, and EditTexts
    EditText newUsernameText, newPasswordText, cPasswordText;
    Button submitButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_user_activity);

        //initializing all variables
        databaseHelper = new DatabaseHelperLogin(this);
        newUsernameText = findViewById(R.id.newUserText);
        newPasswordText = findViewById(R.id.newPasswordText);
        cPasswordText = findViewById(R.id.cPasswordText);
        submitButton = findViewById(R.id.submitButton);

        //on click listener for submitButton
        submitButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivityLogin.this, Login.class);
            startActivity(intent);

        });

        //on click listener for submitButton
        submitButton.setOnClickListener(v -> {
            //get data from al EditText fields
            String username = newUsernameText.getText().toString();
            String password = newPasswordText.getText().toString();
            String confirmPassword = cPasswordText.getText().toString();

            //validating if EditTexts are empty or not
            if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                //if EditText fields left empty display Toast message.
                Toast.makeText(getApplicationContext(), "Enter Required Fields", Toast.LENGTH_SHORT).show();
            } else {
                //validating password and confirmPassword match
                if (password.equals(confirmPassword)) {
                    //validate unique username
                    Boolean checkUsername = databaseHelper.CheckUsername(username);
                    if (checkUsername) {
                        //add new user
                        boolean insert = databaseHelper.Insert(username, password);
                        if (insert) {
                            Toast.makeText(getApplicationContext(), "Registered", Toast.LENGTH_SHORT).show();
                            newUsernameText.setText("");
                            newPasswordText.setText("");
                            cPasswordText.setText("");
                        }
                    } else {
                        //Display Toast message if username is already used to prompt unique usernames for all users
                        Toast.makeText(getApplicationContext(), "Username already exists", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    //display Toast message if password and confirmPassword do not match.
                    Toast.makeText(getApplicationContext(), "Passwords do not match", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


}



















