package com.example.inventoryappnichollecaudy;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Permission extends AppCompatActivity {
    public static final int SMS_PERMISSION_CODE = 101;
    //constant variables
    EditText phoneNumber;
    Button doNotAllowButton, allowButton;
    private String SEND_SMS;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        //initializing variables
        setContentView(R.layout.permission_activity);
        allowButton = findViewById(R.id.allowButton);
        doNotAllowButton = findViewById(R.id.doNotAllowButton);
        phoneNumber = findViewById(R.id.phoneNumberEditText);

        //set on click listener for allowButton
        allowButton.setOnClickListener(v -> {
            if(checkSMSPermission()) {
                //permission granted
                sendSMSNotification("Inventory Item: Inventory item(s) low.");
            }
            else{
                //permission not granted
                requestSMSPermission();
            }
        });
    }



    //checks if the SMS permission is granted
    private boolean checkSMSPermission(){
        return ContextCompat.checkSelfPermission(this, SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    //request SEND_SMS permission from user
    private void requestSMSPermission(){
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION},SMS_PERMISSION_CODE);
    }

    //handles SMS permission request
    public void onRequestPermissionResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == SMS_PERMISSION_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                //permission granted, send SMS
                sendSMSNotification("Inventory Alert: Inventory item(s) low");
            }
            else{
                //permission denied
                Toast.makeText(this, "SMS permission denied. Inventory App will continue to function without SMS notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSMSNotification(String s) {
    }


}
